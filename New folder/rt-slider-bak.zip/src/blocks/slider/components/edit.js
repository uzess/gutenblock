const { Component, Fragment } = wp.element;
const { withSelect } = wp.data;
const { Placeholder, Spinner } = wp.components;
const { __ } = wp.i18n;
const {	BlockAlignmentToolbar, BlockControls } = wp.editor;

import Slider from "react-slick";

import { pickBy, isUndefined } from 'lodash';
import Inspector from './inspector.js';

const { dateI18n, format, __experimentalGetSettings } = wp.date;
const { decodeEntities } = wp.htmlEntities;

class Edit extends Component{

	constructor( props ){
		super( props );
	}

	render(){

		const { 
			className,
			attributes:{
				postsToShow,
				displayPostDate,
				align,
				headingColor,
				headingSize,
			},
			setAttributes, 
			latestPosts 
		} = this.props;

		const hasPosts = Array.isArray( latestPosts ) && latestPosts.length;

		if ( ! hasPosts ) {
			return (
				<Fragment>
					<Inspector {...this.props} />
					<Placeholder
						icon="admin-post"
						label={ __( 'Slider' ) }
					>
						{ ! Array.isArray( latestPosts ) ? <Spinner /> : __( 'No posts found.' ) }
					</Placeholder>
				</Fragment>
			);
		}

		const displayPosts = latestPosts.length > postsToShow ? latestPosts.slice( 0, postsToShow ) : latestPosts;
		const dateFormat = __experimentalGetSettings().formats.date;

		var settings = {
		  dots: true,
		  infinite: true,
		  speed: 500,
		  slidesToShow: 1,
		  slidesToScroll: 1
		};

		return (
			<Fragment>
				<Inspector {...this.props} />

				<BlockControls>
					<BlockAlignmentToolbar
						value={ align }
						onChange={ ( nextAlign ) => {
							setAttributes( { align: nextAlign } );
						} }
					/>
				</BlockControls>

				<div className={ className + ' rt-slider-wrapper' }>
					<Slider {...settings}>
						{ 
							displayPosts.map( ( post, i ) =>{

								const style = {
									textAlign: align,
								};

								if( !isUndefined( post._embedded[ 'wp:featuredmedia' ] ) ){
									style.backgroundImage = `url(${post._embedded[ 'wp:featuredmedia' ][ 0 ].source_url})`;
								}

								return(
									<div key={ i } className="item">
										<div className="item-bg-image" style={style}>
											<h2 style={ {color: headingColor, fontSize: headingSize } }>{ decodeEntities( post.title.rendered.trim() ) || __( '(Untitled)' ) }</h2>
											{ displayPostDate && post.date_gmt &&
												<time dateTime={ format( 'c', post.date_gmt ) } className="wp-block-latest-posts__post-date">
													{ dateI18n( dateFormat, post.date_gmt ) }
												</time>
											}
											<p>{ post.excerpt.raw }</p>
											<a href={ post.link } onClick={ e => e.preventDefault() } target="_blank">
												Read More
											</a>
										</div>
									</div>
								);
							})
						}
					</Slider>
				</div>
				
			</Fragment>
		);
	}
}

export default withSelect( ( select, props ) => {

	const { postsToShow, order, orderBy, categories } = props.attributes;
	const { getEntityRecords } = select( 'core' );

	const latestPostsQuery = pickBy( {
		categories,
		order,
		orderby: orderBy,
		per_page: postsToShow,
		_embed: true,
		withcomments: true,
	}, ( value ) => ! isUndefined( value ) );

	return {
		latestPosts: getEntityRecords( 'postType', 'post', latestPostsQuery ),
	};

} )( Edit );