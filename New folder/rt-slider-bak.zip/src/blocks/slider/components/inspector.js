const { Component } = wp.element;
const { InspectorControls } = wp.editor;
const { ToggleControl, PanelBody, QueryControls, ColorPalette, FontSizePicker  } = wp.components;
const { __ } = wp.i18n;

const { addQueryArgs } = wp.url;

export default class Inspector extends Component{

	constructor( props ){
		super( props );
		this.state = {
			categoriesList: [],
		};
	}

	componentWillMount() {

		this.isStillMounted = true;

		const onGet = ( categoriesList ) => {
			if ( this.isStillMounted ) {
				this.setState( { categoriesList } );
			}
		};

		const onError = () => {
			if ( this.isStillMounted ) {
				this.setState( { categoriesList: [] } );
			}
		}

		const CATEGORIES_LIST_QUERY = {
			per_page: -1,
		};

		const params = {
			path: addQueryArgs( `/wp/v2/categories`, CATEGORIES_LIST_QUERY ),
		};

		this.fetchRequest = wp.apiFetch( params ).then( onGet ).catch( onError );
	}

	componentWillUnmount() {
		this.isStillMounted = false;
	}

	toggleDisplayPostDate() {
		const { displayPostDate } = this.props.attributes;
		this.props.setAttributes( { displayPostDate: ! displayPostDate } );
	}

	render(){

		const { 
			setAttributes,
			attributes:{
				order,
				orderBy,
				categories,
				postsToShow,
				displayPostDate,
				headingColor,
				headingSize,
			} 
		} = this.props;

		console.log( headingColor );

		const { categoriesList } = this.state;
		const fontSizes = [
		    {
		        name: __( 'Small' ),
		        slug: 'small',
		        size: 12,
		    },
		    {
		        name: __( 'Big' ),
		        slug: 'big',
		        size: 26,
		    },
		];

		const fallbackFontSize = 16;

		return(
			<InspectorControls>
				<PanelBody title={ __( 'General' ) } initialOpen={false}>
					<QueryControls
						{ ...{ order, orderBy } }
						categoriesList={ categoriesList }
						selectedCategoryId={ categories }
						numberOfItems={ postsToShow }
						onCategoryChange={ ( value ) => setAttributes( { categories: '' !== value ? value : undefined } )  } 
						onNumberOfItemsChange={ ( value ) => setAttributes( { postsToShow: value } ) } 
						onOrderChange={ ( value ) => setAttributes( { order: value } ) }
						onOrderByChange={ ( value ) => setAttributes( { orderBy: value } ) }
					/>
					<ToggleControl
						label={ __( 'Display post date' ) }
						checked={ displayPostDate }
						onChange={ () => this.toggleDisplayPostDate() }
					/>
				</PanelBody>
				<PanelBody title={ __( 'Typography' ) } initialOpen={false}>
					<FontSizePicker
					    fontSizes={ fontSizes }
					    value={ headingSize }
					    fallbackFontSize={ fallbackFontSize }
					    onChange={ ( headingSize ) => {
					        setAttributes( { headingSize } );
					    } }
					/>
				</PanelBody>
				<PanelBody title={ __( 'Color Settings' ) } initialOpen={false}>
					<label>Heading Color</label>
					<ColorPalette 
					    colors={ [ 
					        { name: 'red', color: '#f00' }, 
					        { name: 'white', color: '#fff' }, 
					        { name: 'blue', color: '#00f' }, 
					    ] } 
					    value={ headingColor }
					    onChange={ ( headingColor ) => setAttributes( { headingColor } ) } 
					/>

				</PanelBody>
			</InspectorControls>
		);
	}
}