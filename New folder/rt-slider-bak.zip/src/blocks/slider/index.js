import './styles/style.scss';
import './styles/editor.scss';

const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

import edit from './components/edit.js';
import save from './components/save.js';

registerBlockType( 'riseblock/slider', {
	title : __( 'RT Slider' ),
	icon: 'shield',
	attributes: {
		displayPostDate: {
			type: 'boolean',
			default: false
		},
		categories: {
			type: 'string'
		},
		postsToShow: {
			type: 'number',
			default: 5
		},
		order: {
			type   : 'string',
			default: 'desc',
		},
		orderBy: {
			type    : 'string',
			default : 'date',
		},
		headingColor: {
			type: 'string',
		},
		headingSize: {
			type: 'number',
		},
		align: {
			type: 'string',
			default: 'center',
		}
	},
	category: 'common',
	edit,
	save,
});