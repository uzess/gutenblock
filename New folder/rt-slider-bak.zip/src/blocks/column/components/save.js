const { InnerBlocks  } = wp.editor;
const Save = () => <div className="rt-column-wrapper">
	<InnerBlocks.Content />
</div>;

export default Save;