<?php
/**
 * Plugin Name: rt-slider — CGB Gutenberg Block Plugin
 * Plugin URI: https://github.com/ahmadawais/create-guten-block/
 * Description: rt-slider — is a Gutenberg plugin created via create-guten-block.
 * Author: mrahmadawais, maedahbatool
 * Author URI: https://AhmadAwais.com/
 * Version: 1.0.0
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 *
 * @package CGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Block Initializer.
 */
require_once plugin_dir_path( __FILE__ ) . 'src/init.php';
add_action( 'wp_head', function(){
	$id = get_the_ID();
	$content = get_post_field( 'post_content', $id );
	$temp = parse_blocks( $content );
});

class PostCommentsWPAPI {
	function __construct() {
		if ( isset( $_GET['withcomments'] ) ) {
		
			add_filter( 'rest_prepare_post', array( &$this, 'get_comments_for_posts' ), 10, 3 );
		}
	}

	function get_comments_for_posts( $data, $post, $context ) {

		$comments = get_comments( array( 'post_id' => $post->ID ) ) ;
		
		foreach ( $comments as $comment ) {
			$user_id = $comment->user_id;

			$author = [
				'ID' => $user_id,
				'username' => get_the_author_meta( 'user_login', $user_id ),
				'name' => get_the_author_meta( 'display_name', $user_id ),
				'first_name' => get_the_author_meta( 'first_name', $user_id ),
				'last_name' => get_the_author_meta( 'last_name', $user_id ),
				'avatar' => get_avatar_url( $user_id ),
				'description' => get_the_author_meta( 'description', $user_id )
			];

			$data->data['comments'][] = [
				'ID' => $comment->comment_ID,
				'post' => $comment->comment_post_ID,
				'content' => $comment->comment_content,
				'author' => $author,
				'date' => $comment->comment_date,
				'date_gmt' => $comment->comment_date_gmt
			];
		}

		return $data;
	}
}

$PostCommentsWPAPI = new PostCommentsWPAPI();